
Integrantes: 
	    -Jose Quezada Silva		rol: 201773528-7
	    -Martin Salinas Scussolin 	rol: 201773557-0

Instrucciones del notebook:

	    Correr las celdas del notebook normalmente.
	    Se necesitan las librerias pandas, numpy, scipy, matpotlib.pyplot, 
	    matplotlib.dates

Obs: 	    En el inciso 2.1, la parte del grafico de 100000 agujas requiere un tiempo
	    considerable para correr.
	    Se incluyen alguna imagenes necesarias para el notebook en la carpeta img.
