
Integrantes: 
	    -Jose Quezada Silva		    rol: 201773528-7
	    -Martin Salinas Scussolin 	rol: 201773557-0

Instrucciones del notebook:

	    Correr las celdas del notebook normalmente.
	    Se necesitan las librerias pandas, numpy, scipy, matpotlib.pyplot, random,
        statistics, math, seaborn.